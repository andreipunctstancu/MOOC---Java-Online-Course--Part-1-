package tests;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;
import setup.TestSetup;

import java.util.concurrent.TimeUnit;

public class LoginTest extends TestSetup {

    private HomePage homePage;
    private LoginPage loginPage;

    @Override
    @BeforeMethod
    public void setUp () {
        super.setUp();
        homePage = PageFactory.initElements(driver, HomePage.class);
        loginPage = PageFactory.initElements(driver, LoginPage.class);
    }



    @Override
    @AfterMethod
    public void tearDown () {
        super.tearDown();
        homePage = null;
        loginPage = null;
    }

    @Test
    public void validLogin () {
        openApp("https://www.phptravels.net/");
        wait(2000);
        homePage.navigateToLoginPage();
        wait(2000);
        loginPage.performLogin("user@phptravels.com", "demouser");
        wait(2000);
        String actualTitle = driver.getTitle();
        Assert.assertEquals(actualTitle, "My Account");
    }

    @Test
    public void loginInvalidUserValidPass () {
        openApp("https://www.phptravels.net/");
        wait(2000);
        homePage.navigateToLoginPage();
        loginPage.performLogin("user@gmail.com", "demouser");
        wait(5000);
        Assert.assertEquals(loginPage.getInvalidLoginMessage(), "Invalid Email or Password");
    }

    @Test
    public void loginValidUserInvalidPass () {
        openApp("https://www.phptravels.net/");
        wait(2000);
        homePage.navigateToLoginPage();
        loginPage.performLogin("user@phptravels.com", "password");
        wait(5000);
        Assert.assertEquals(loginPage.getInvalidLoginMessage(), "Invalid Email or Password");
    }

    @Test
    public void loginInvalidUserInvalidPass () {
        openApp("https://www.phptravels.net/");
        wait(2000);
        homePage.navigateToLoginPage();
        loginPage.performLogin("user@gmail.com", "password");
        wait(5000);
        Assert.assertEquals(loginPage.getInvalidLoginMessage(), "Invalid Email or Password");
    }

    

}