package setup;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class TestSetup {
    protected  WebDriver driver;

    @BeforeMethod
    protected void setUp () {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\andrei.stancu\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
        driver = new ChromeDriver();
    }

    @AfterMethod
    protected void tearDown () {
        driver.close();
        driver = null;
    }




     public void openApp (String url) {
         driver.manage().window().maximize();
         driver.get(url);
     }

     public void wait (int timeout) {
         try {
             Thread.sleep(timeout);
         } catch (InterruptedException e) {
             e.printStackTrace();
         }
     }



    }
