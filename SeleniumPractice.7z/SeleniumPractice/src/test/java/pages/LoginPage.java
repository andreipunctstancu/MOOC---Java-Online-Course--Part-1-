package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class LoginPage {

    @FindBy(xpath = "//*[@id=\"loginfrm\"]/div[1]/div[5]/div/div[1]/input")
    private WebElement userNameField;

    @FindBy(xpath = "//*[@id=\"loginfrm\"]/div[1]/div[5]/div/div[2]/input")
    private WebElement passwordField;

    @FindBy(xpath = "//*[@id=\"loginfrm\"]/div[1]/div[5]/button")
    private WebElement loginButton;

    @FindBy(id = "remember-me")
    private WebElement rememberMeCheckBox;

    @FindBy(name = "Sign Up")
    private WebElement signUpButton;

    @FindBy(name = "Forget Password")
    private WebElement forgetPasswordButton;

    @FindBy(className = "resultlogin")
    private WebElement loginFailedNotification;

    public void performLogin (String username, String password) {
        userNameField.sendKeys(username);
        passwordField.sendKeys(password);
        loginButton.click();
    }

    public String getInvalidLoginMessage() {
        return loginFailedNotification.getText();
    }
}



