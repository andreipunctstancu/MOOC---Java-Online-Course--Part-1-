package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage {

    @FindBy(linkText = "MY ACCOUNT")
    private WebElement myAccountButton;

    @FindBy(linkText = "Login")
    private WebElement loginButton;

    public void navigateToLoginPage () {
        myAccountButton.click();
        loginButton.click();
    }

}
